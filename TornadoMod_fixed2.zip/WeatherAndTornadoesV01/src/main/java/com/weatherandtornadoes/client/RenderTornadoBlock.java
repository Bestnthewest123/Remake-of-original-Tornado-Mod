package com.weatherandtornadoes.client;

import com.weatherandtornadoes.entity.EntityTornadoBlock;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

/** Renders carried states with vanilla atlas textures and no entity shadow. */
@SideOnly(Side.CLIENT)
public class RenderTornadoBlock extends Render<EntityTornadoBlock> {
    public RenderTornadoBlock(RenderManager renderManager) {
        super(renderManager);
        this.shadowSize = 0.0F;
    }

    @Override
    public void doRender(EntityTornadoBlock entity, double x, double y, double z, float entityYaw, float partialTicks) {
        IBlockState state = entity.getCarriedState();
        Block block = state.getBlock();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x - 0.5D, y, z - 0.5D);
        bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.disableLighting();

        if (block == Blocks.FIRE) {
            renderFire();
        } else if (state.getMaterial() == Material.WATER || block == Blocks.WATER || block == Blocks.FLOWING_WATER) {
            renderWater();
        } else if (state.getRenderType() == EnumBlockRenderType.MODEL) {
            BlockRendererDispatcher dispatcher = Minecraft.getMinecraft().getBlockRendererDispatcher();
            dispatcher.renderBlockBrightness(state, 1.0F);
        }

        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    private void renderWater() {
        TextureAtlasSprite sprite = Minecraft.getMinecraft().getTextureMapBlocks().getAtlasSprite("minecraft:blocks/water_still");
        double u0 = sprite.getMinU();
        double u1 = sprite.getMaxU();
        double v0 = sprite.getMinV();
        double v1 = sprite.getMaxV();
        // Slightly inset, translucent cube. The atlas sprite remains animated by vanilla.
        double a = 0.06D, b = 0.94D;
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        buffer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX_COLOR);
        quad(buffer, a,a,a, b,a,a, b,b,a, a,b,a, u0,v0,u1,v1, 150);
        quad(buffer, a,a,b, a,b,b, b,b,b, b,a,b, u0,v0,u1,v1, 150);
        quad(buffer, a,a,a, a,b,a, a,b,b, a,a,b, u0,v0,u1,v1, 150);
        quad(buffer, b,a,a, b,a,b, b,b,b, b,b,a, u0,v0,u1,v1, 150);
        quad(buffer, a,b,a, b,b,a, b,b,b, a,b,b, u0,v0,u1,v1, 150);
        quad(buffer, a,a,a, a,a,b, b,a,b, b,a,a, u0,v0,u1,v1, 150);
        Tessellator.getInstance().draw();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
    }

    private void renderFire() {
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        TextureAtlasSprite sprite = Minecraft.getMinecraft().getTextureMapBlocks().getAtlasSprite("minecraft:blocks/fire_layer_0");
        double u0 = sprite.getMinU();
        double u1 = sprite.getMaxU();
        double v0 = sprite.getMinV();
        double v1 = sprite.getMaxV();
        BufferBuilder buffer = Tessellator.getInstance().getWorldRenderer();
        buffer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        // Two crossed, vertical planes mimic the vanilla fire billboards; no rotation/tilt.
        buffer.pos(0.05D, 0.0D, 0.05D).tex(u0,v1).endVertex();
        buffer.pos(0.95D, 0.0D, 0.95D).tex(u1,v1).endVertex();
        buffer.pos(0.95D, 1.0D, 0.95D).tex(u1,v0).endVertex();
        buffer.pos(0.05D, 1.0D, 0.05D).tex(u0,v0).endVertex();
        buffer.pos(0.05D, 0.0D, 0.95D).tex(u0,v1).endVertex();
        buffer.pos(0.95D, 0.0D, 0.05D).tex(u1,v1).endVertex();
        buffer.pos(0.95D, 1.0D, 0.05D).tex(u1,v0).endVertex();
        buffer.pos(0.05D, 1.0D, 0.95D).tex(u0,v0).endVertex();
        Tessellator.getInstance().draw();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
    }

    private void quad(BufferBuilder buffer,
                      double x1,double y1,double z1, double x2,double y2,double z2,
                      double x3,double y3,double z3, double x4,double y4,double z4,
                      double u0,double v0,double u1,double v1, int alpha) {
        buffer.pos(x1,y1,z1).tex(u0,v1).color(255,255,255,alpha).endVertex();
        buffer.pos(x2,y2,z2).tex(u1,v1).color(255,255,255,alpha).endVertex();
        buffer.pos(x3,y3,z3).tex(u1,v0).color(255,255,255,alpha).endVertex();
        buffer.pos(x4,y4,z4).tex(u0,v0).color(255,255,255,alpha).endVertex();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityTornadoBlock entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}

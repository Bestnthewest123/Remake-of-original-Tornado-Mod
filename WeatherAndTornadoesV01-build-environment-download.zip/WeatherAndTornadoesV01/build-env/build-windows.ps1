$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ToolsDir = Join-Path $ProjectRoot '.build-tools'
New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null

function Download-File($Url, $Destination) {
    Write-Host "Downloading $Url"
    Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing
}

# This legacy ForgeGradle 2.2 project should be built with Java 8 and Gradle 2.14.1.
$JdkZip = Join-Path $ToolsDir 'temurin-jdk8.zip'
$GradleZip = Join-Path $ToolsDir 'gradle-2.14.1-bin.zip'
$JdkDir = Join-Path $ToolsDir 'jdk8'
$GradleDir = Join-Path $ToolsDir 'gradle-2.14.1'

if (-not (Test-Path $JdkDir)) {
    Download-File 'https://api.adoptium.net/v3/binary/latest/8/ga/windows/x64/jdk/hotspot/normal/eclipse' $JdkZip
    Expand-Archive -Path $JdkZip -DestinationPath $ToolsDir -Force
    $ExtractedJdk = Get-ChildItem $ToolsDir -Directory | Where-Object { $_.Name -like 'jdk8*' -or $_.Name -like 'jdk-8*' } | Select-Object -First 1
    if (-not $ExtractedJdk) { throw 'Could not locate extracted Java 8 JDK.' }
    Move-Item $ExtractedJdk.FullName $JdkDir -Force
}
if (-not (Test-Path $GradleDir)) {
    Download-File 'https://services.gradle.org/distributions/gradle-2.14.1-bin.zip' $GradleZip
    Expand-Archive -Path $GradleZip -DestinationPath $ToolsDir -Force
    $ExtractedGradle = Join-Path $ToolsDir 'gradle-2.14.1'
    if (-not (Test-Path $ExtractedGradle)) { throw 'Could not locate extracted Gradle 2.14.1.' }
}

$JavaExe = Get-ChildItem $JdkDir -Filter java.exe -Recurse | Select-Object -First 1
if (-not $JavaExe) { throw 'Java 8 java.exe was not found.' }
$env:JAVA_HOME = Split-Path -Parent (Split-Path -Parent $JavaExe.FullName)
$env:PATH = "$($env:JAVA_HOME)\bin;$env:PATH"
Write-Host 'Java version:'
& $JavaExe.FullName -version
Write-Host 'Starting ForgeGradle build. The first build needs internet access to download Minecraft/Forge dependencies.'
Push-Location $ProjectRoot
try {
    & (Join-Path $GradleDir 'bin\gradle.bat') --no-daemon clean build
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
    Write-Host 'Build completed. Check build\libs for the mod JAR.'
} finally { Pop-Location }

package com.weatherandtornadoes;

import com.weatherandtornadoes.command.CommandSpawnTornado;
import com.weatherandtornadoes.entity.EntityTornado;
import com.weatherandtornadoes.entity.EntityTornadoBlock;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid = WeatherAndTornadoes.MODID, name = WeatherAndTornadoes.NAME, version = WeatherAndTornadoes.VERSION, acceptedMinecraftVersions = "[1.10.2]")
public class WeatherAndTornadoes {
    public static final String MODID = "weatherandtornadoes";
    public static final String NAME = "Weather and Tornadoes";
    public static final String VERSION = "0.1-alpha";

    @SidedProxy(clientSide = "com.weatherandtornadoes.client.ClientProxy", serverSide = "com.weatherandtornadoes.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(EntityTornado.class, "ef1_tornado", 0, this, 128, 1, true);
        EntityRegistry.registerModEntity(EntityTornadoBlock.class, "tornado_block", 1, this, 128, 1, true);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.registerRenderers();
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandSpawnTornado());
    }
}

package com.weatherandtornadoes;

/** Common-side hooks. Client-only rendering is registered in ClientProxy. */
public class CommonProxy {
    public void registerRenderers() {
        // Intentionally empty on a dedicated server.
    }
}

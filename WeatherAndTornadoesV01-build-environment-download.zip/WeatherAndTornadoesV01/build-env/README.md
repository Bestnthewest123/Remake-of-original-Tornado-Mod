# Build environment bootstrap

This project uses the legacy ForgeGradle 2.2 toolchain for Minecraft Forge 1.10.2. The bootstrap scripts are configured for **Java 8 + Gradle 2.14.1**; they do not use the Java 21 currently present in the earlier build container.

## Windows PC
1. Extract the whole project folder.
2. Install/use a recent Windows PowerShell.
3. Open PowerShell in the project folder and run:
   `powershell -ExecutionPolicy Bypass -File .\build-env\build-windows.ps1`
4. The script downloads a Java 8 JDK and Gradle 2.14.1 into `.build-tools`, then runs `clean build`.

## Linux PC
1. Install `curl`, `tar`, and `unzip`.
2. From the project folder, run: `bash build-env/build-linux.sh`
3. The script downloads Java 8 and Gradle 2.14.1 into `.build-tools`, then runs `clean build`.

## Important limits
- An internet connection is required on the build computer for the initial tool downloads and Forge/Minecraft dependencies.
- This creates a build environment; it does **not** mean the mod has already compiled or passed an in-game test.
- If the build fails, save the complete console output and fix the first reported error before retrying.
- These scripts are intended for a Windows or Linux computer, not directly for a Kindle Fire tablet.
- Expected final filename: `Weather and Tornadoes v0.1 Alpha.jar` in `build/libs` if the build succeeds.

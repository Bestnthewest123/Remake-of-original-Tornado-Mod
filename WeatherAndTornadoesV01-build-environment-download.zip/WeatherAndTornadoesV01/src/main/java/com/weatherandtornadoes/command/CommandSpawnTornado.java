package com.weatherandtornadoes.command;

import com.weatherandtornadoes.entity.EntityTornado;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Collections;
import java.util.List;

/** Simple test-mode command: /tornado [x y z] */
public class CommandSpawnTornado extends CommandBase {
    @Override
    public String getCommandName() {
        return "tornado";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/tornado [x y z] - spawns the EF1 test tornado";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        World world = sender.getEntityWorld();
        BlockPos pos = sender.getPosition();
        double x = pos.getX() + 0.5D;
        double y = pos.getY() + 0.1D;
        double z = pos.getZ() + 0.5D;
        if (args.length != 0 && args.length != 3) {
            throw new CommandException(getCommandUsage(sender));
        }
        if (args.length == 3) {
            x = parseDouble(x, args[0], true);
            y = parseDouble(y, args[1], 0.0D, 255.0D, false);
            z = parseDouble(z, args[2], true);
        }
        EntityTornado tornado = new EntityTornado(world, x, y, z);
        if (!world.spawnEntityInWorld(tornado)) {
            throw new CommandException("Could not spawn the EF1 tornado.");
        }
        notifyCommandListener(sender, this, "Spawned the EF1 test tornado.");
    }

    @Override
    public List<String> getTabCompletionOptions(MinecraftServer server, ICommandSender sender, String[] args, BlockPos targetPos) {
        return Collections.emptyList();
    }
}

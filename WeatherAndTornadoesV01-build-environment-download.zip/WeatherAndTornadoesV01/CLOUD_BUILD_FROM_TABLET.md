# Build from a Kindle Fire using a cloud build

You do not run this legacy ForgeGradle build directly on the Kindle. Instead, use the Kindle's browser to configure GitHub Actions, which runs Java 8 and Gradle 2.14.1 on a hosted Linux runner.

1. Sign in to GitHub in the tablet browser and create a new repository. For a private project, choose **Private**.
2. Upload the project files from this folder into the repository, including the hidden `.github/workflows/build.yml` file. If the browser's upload picker makes folders difficult, create/upload the files through GitHub's web interface. The workflow must be at `.github/workflows/build.yml` in the repository root.
3. Open the repository's **Actions** tab and choose **Build Weather and Tornadoes 1.10.2**. Use **Run workflow** if shown, or push a change to trigger it.
4. Wait for the run to finish. A green check means the build command succeeded; it does not prove the mod works in game.
5. Open the successful run, find **Artifacts**, and download `Weather-and-Tornadoes-v0.1-Alpha`. Extract it to get `Weather and Tornadoes v0.1 Alpha.jar`.
6. If the build fails, open the run log and save/copy the first error section so it can be diagnosed.

The workflow is an attempted build setup, not a guarantee of success. This legacy project has not yet been compiled or tested in Minecraft.

Weather and Tornadoes V0.1 Alpha — internal implementation notes
Target: Minecraft Java Edition 1.10.2 + Forge 12.18.3.2511.
Requested artifact filename: Weather and Tornadoes v0.1 Alpha.jar

Implemented in source:
- EF1 tornado entity with a 10-minute lifetime.
- String-textured tapered funnel renderer; tornado has no shadow and cannot be attacked/collided with.
- Up to 25 block visual entities per tornado, with a 10-pickup-attempts-per-second target.
- Reuses the 25 visual slots after the cap is reached so pickups can continue without spawning more entities.
- Picks up solid blocks plus fire and water; skips tile entities to avoid consuming inventories.
- Block states retain their metadata/orientation, and the visual entities are kept upright.
- Vanilla block model rendering for normal blocks, animated atlas sprites for fire/water visuals.
- Flying block entities have zero shadow size and cannot be hit or pushed.
- /tornado command for test spawning.

Build status:
- Source project is prepared, but a Forge 1.10.2 JAR has NOT been compiled or runtime-tested in this environment.
- The environment currently has Java 21, no installed Gradle, and no network access to download the old Gradle/ForgeGradle toolchain. Forge 1.10.2 projects generally require the legacy Java 8-era toolchain, so successful compilation must be verified in a compatible build environment.

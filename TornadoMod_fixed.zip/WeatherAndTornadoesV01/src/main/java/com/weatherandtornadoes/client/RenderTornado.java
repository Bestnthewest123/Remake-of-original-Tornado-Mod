package com.weatherandtornadoes.client;

import com.weatherandtornadoes.entity.EntityTornado;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

/** String-textured EF1 funnel with no entity shadow. */
@SideOnly(Side.CLIENT)
public class RenderTornado extends Render<EntityTornado> {
    public RenderTornado(RenderManager renderManager) {
        super(renderManager);
        this.shadowSize = 0.0F;
    }

    @Override
    public void doRender(EntityTornado entity, double x, double y, double z, float entityYaw, float partialTicks) {
        TextureAtlasSprite string = Minecraft.getMinecraft().getTextureMapBlocks().getAtlasSprite("minecraft:items/string");
        double u0 = string.getMinU();
        double u1 = string.getMaxU();
        double v0 = string.getMinV();
        double v1 = string.getMaxV();
        double time = entity.ticksExisted + partialTicks;

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);

        BufferBuilder buffer = Tessellator.getInstance().getWorldRenderer();
        buffer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        // Multiple narrow string-textured ribbons make a simple, tapered funnel.
        final int ribbons = 16;
        for (int i = 0; i < ribbons; i++) {
            double a = (Math.PI * 2.0D * i / ribbons) + time * 0.035D;
            double a2 = a + 0.18D;
            double bottomRadius = 1.5D;
            double middleRadius = 4.0D;
            double topRadius = 0.25D;
            addRibbon(buffer, Math.cos(a) * bottomRadius, Math.sin(a) * bottomRadius,
                    Math.cos(a2) * bottomRadius, Math.sin(a2) * bottomRadius,
                    Math.cos(a) * middleRadius, Math.sin(a) * middleRadius,
                    Math.cos(a2) * middleRadius, Math.sin(a2) * middleRadius,
                    0.0D, 18.0D, u0, u1, v0, v1);
            addRibbon(buffer, Math.cos(a) * middleRadius, Math.sin(a) * middleRadius,
                    Math.cos(a2) * middleRadius, Math.sin(a2) * middleRadius,
                    Math.cos(a) * topRadius, Math.sin(a) * topRadius,
                    Math.cos(a2) * topRadius, Math.sin(a2) * topRadius,
                    18.0D, 45.0D, u0, u1, v0, v1);
        }
        Tessellator.getInstance().draw();

        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    private void addRibbon(BufferBuilder buffer,
                           double bx1, double bz1, double bx2, double bz2,
                           double tx1, double tz1, double tx2, double tz2,
                           double bottomY, double topY, double u0, double u1, double v0, double v1) {
        buffer.pos(bx1, bottomY, bz1).tex(u0, v1).endVertex();
        buffer.pos(bx2, bottomY, bz2).tex(u1, v1).endVertex();
        buffer.pos(tx2, topY, tz2).tex(u1, v0).endVertex();
        buffer.pos(tx1, topY, tz1).tex(u0, v0).endVertex();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityTornado entity) {
        return TextureMap.LOCATION_BLOCKS_TEXTURE;
    }
}

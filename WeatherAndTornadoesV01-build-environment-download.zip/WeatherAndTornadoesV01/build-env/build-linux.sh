#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS="$ROOT/.build-tools"
mkdir -p "$TOOLS"

# This legacy ForgeGradle 2.2 project should be built with Java 8 and Gradle 2.14.1.
if ! command -v curl >/dev/null 2>&1; then echo 'curl is required.' >&2; exit 1; fi
if [ ! -d "$TOOLS/jdk8" ]; then
  curl -fL 'https://api.adoptium.net/v3/binary/latest/8/ga/linux/x64/jdk/hotspot/normal/eclipse' -o "$TOOLS/temurin-jdk8.tar.gz"
  mkdir -p "$TOOLS/jdk8"
  tar -xzf "$TOOLS/temurin-jdk8.tar.gz" -C "$TOOLS/jdk8" --strip-components=1
fi
if [ ! -d "$TOOLS/gradle-2.14.1" ]; then
  curl -fL 'https://services.gradle.org/distributions/gradle-2.14.1-bin.zip' -o "$TOOLS/gradle-2.14.1-bin.zip"
  unzip -q -o "$TOOLS/gradle-2.14.1-bin.zip" -d "$TOOLS"
fi
export JAVA_HOME="$TOOLS/jdk8"
export PATH="$JAVA_HOME/bin:$PATH"
java -version
cd "$ROOT"
echo 'Starting ForgeGradle build. The first build needs internet access to download Minecraft/Forge dependencies.'
"$TOOLS/gradle-2.14.1/bin/gradle" --no-daemon clean build
echo 'Build completed. Check build/libs for the mod JAR.'

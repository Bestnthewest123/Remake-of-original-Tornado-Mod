# Weather and Tornadoes V0.1 Alpha — Test Source

Target: Minecraft Java Edition 1.10.2 with Minecraft Forge 12.18.3.2511.

Requested final artifact name: `Weather and Tornadoes v0.1 Alpha.jar`.

## Test-mode contents

- One EF1-style tornado entity, rendered as a string-textured funnel.
- `/tornado` command (permission level 2) to spawn a test tornado.
- A target of 10 ground-pickup attempts per second (one attempt every two game ticks at 20 TPS).
- Up to 25 active visual block entities per tornado.
- A funnel visual reaching 45 blocks high and a rotating spherical block formation.
- Ten-minute lifetime.
- Vanilla block atlas rendering; fire and water have dedicated animated-atlas visual paths.
- Carried blocks remain upright; carried visuals have no entity shadow and cannot be attacked or collided with.
- Tile entities are skipped so containers and other tile-entity blocks are not removed.

## Build environment

This is a legacy ForgeGradle 2.2 project. It normally requires a Java 8-era toolchain and internet access on the first build to resolve ForgeGradle and Minecraft dependencies. Use Gradle 2.14.x with Java 8 for the most compatible environment.

From the project directory, run:

```sh
gradle build
```

The intended output is under `build/libs/` with the requested JAR filename. The project has not yet been compiled or runtime-tested in this environment; the available environment has Java 21, no Gradle installation, and cannot resolve external hosts, so dependency resolution/build verification cannot currently run here.

## Important test limitations

This is a first-pass test implementation, not a verified release. Rendering and behavior must be checked in an actual Forge 1.10.2 client. Fire and water are rendered as moving visuals rather than running all world behaviors (such as fire spreading or fluid flow) while airborne. Block pickup changes the world, so test in a disposable world.

## Build setup
See `build-env/README.md` for the Java 8 + Gradle 2.14.1 bootstrap scripts for Windows and Linux. The source has not yet been compiled or tested in Minecraft; successful build output is not guaranteed until the scripts are run on an internet-connected compatible computer.

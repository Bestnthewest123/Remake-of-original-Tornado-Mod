package com.weatherandtornadoes.entity;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Basic EF1 test tornado for Forge 1.10.2.
 * Keeps at most 25 block visuals, targets 10 pickups/second, reaches 45 blocks,
 * and expires after ten minutes.
 */
public class EntityTornado extends Entity {
    public static final int MAX_BLOCK_ENTITIES = 25;
    public static final int MAX_HEIGHT = 45;
    public static final int LIFETIME_TICKS = 20 * 60 * 10;
    private static final int PICKUP_INTERVAL_TICKS = 2;
    private static final double SPHERE_RADIUS = MAX_HEIGHT / 2.0D;

    private final List<EntityTornadoBlock> carried = new ArrayList<EntityTornadoBlock>();
    private int age;
    private int pickupTick;
    private int replaceIndex;
    private double phase;

    public EntityTornado(World world) {
        super(world);
        this.setSize(1.2F, 3.0F);
        this.preventEntitySpawning = true;
    }

    public EntityTornado(World world, double x, double y, double z) {
        this(world);
        this.setPosition(x, y, z);
    }

    @Override
    protected void entityInit() { }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) return;

        age++;
        if (age >= LIFETIME_TICKS) {
            for (EntityTornadoBlock block : carried) {
                if (block != null && !block.isDead) block.setDead();
            }
            carried.clear();
            setDead();
            return;
        }

        phase += 0.12D;
        if (phase >= Math.PI * 2.0D) phase -= Math.PI * 2.0D;
        updateCarriedBlocks();

        // 20 game ticks/second: one pickup attempt every two ticks = 10 TPS.
        if (++pickupTick >= PICKUP_INTERVAL_TICKS) {
            pickupTick = 0;
            pickupGroundBlock();
        }
    }

    private void updateCarriedBlocks() {
        int count = carried.size();
        if (count == 0) return;

        for (int i = count - 1; i >= 0; i--) {
            EntityTornadoBlock block = carried.get(i);
            if (block == null || block.isDead) {
                carried.remove(i);
                continue;
            }

            // Blocks spiral through a circular cross-section, creating a spherical shell.
            double y = (age * 0.035D + i * (MAX_HEIGHT / (double) count)) % MAX_HEIGHT;
            double sphereFactor = Math.sin((y / MAX_HEIGHT) * Math.PI);
            double radius = SPHERE_RADIUS * sphereFactor;
            double angle = phase + i * (Math.PI * 2.0D / count);
            block.setPosition(posX + Math.cos(angle) * radius, posY + y, posZ + Math.sin(angle) * radius);
            block.setOrbit(radius, angle, y);
            // Keep the entity and its carried block state upright; only its position changes.
            block.prevRotationYaw = block.rotationYaw = 0.0F;
            block.prevRotationPitch = block.rotationPitch = 0.0F;
        }
    }

    private void pickupGroundBlock() {
        BlockPos base = new BlockPos(posX, posY, posZ);
        for (int r = 1; r <= 3; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos p = base.add(dx, -1, dz);
                    if (!world.isBlockLoaded(p)) continue;
                    IBlockState state = world.getBlockState(p);
                    Block block = state.getBlock();
                    Material material = state.getMaterial();
                    boolean fire = block == Blocks.FIRE;
                    boolean water = material == Material.WATER || block == Blocks.WATER || block == Blocks.FLOWING_WATER;

                    if (block.isAir(state, world, p) || material == Material.AIR) continue;
                    if (!fire && !water && !material.isSolid()) continue;
                    if (!fire && !water && block.isReplaceable(world, p)) continue;
                    if (block.hasTileEntity(state)) continue; // Do not consume inventories or other tile entities.
                    if (!fire && !water && block.getBlockHardness(world, p) < 0.0F) continue;

                    // Fire and water are intentionally allowed even though they are replaceable.
                    world.setBlockToAir(p);
                    acceptPickup(state);
                    return;
                }
            }
        }
    }

    private void acceptPickup(IBlockState state) {
        if (carried.size() < MAX_BLOCK_ENTITIES) {
            EntityTornadoBlock entity = new EntityTornadoBlock(world, posX, posY + 1.0D, posZ, state);
            carried.add(entity);
            world.spawnEntityInWorld(entity);
        } else if (!carried.isEmpty()) {
            // Reuse one of the 25 visuals so pickup can continue without exceeding the cap.
            EntityTornadoBlock entity = carried.get(replaceIndex % carried.size());
            replaceIndex = (replaceIndex + 1) % carried.size();
            entity.setCarriedState(state);
        }
    }

    @Override
    public boolean canBeCollidedWith() { return false; }

    @Override
    public boolean canBePushed() { return false; }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) { return false; }

    @Override
    protected void readEntityFromNBT(NBTTagCompound tag) {
        age = tag.getInteger("Age");
        pickupTick = tag.getInteger("PickupTick");
        replaceIndex = tag.getInteger("ReplaceIndex");
        phase = tag.getDouble("Phase");
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound tag) {
        tag.setInteger("Age", age);
        tag.setInteger("PickupTick", pickupTick);
        tag.setInteger("ReplaceIndex", replaceIndex);
        tag.setDouble("Phase", phase);
    }
}

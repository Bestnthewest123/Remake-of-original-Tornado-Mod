package com.weatherandtornadoes.client;

import com.weatherandtornadoes.CommonProxy;
import com.weatherandtornadoes.entity.EntityTornado;
import com.weatherandtornadoes.entity.EntityTornadoBlock;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityTornado.class, RenderTornado::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityTornadoBlock.class, RenderTornadoBlock::new);
    }
}

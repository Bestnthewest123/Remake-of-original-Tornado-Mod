package com.weatherandtornadoes.entity;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/** A non-collidable, non-attackable moving visual that preserves the picked-up block state. */
public class EntityTornadoBlock extends Entity {
    private static final DataParameter<Integer> BLOCK_ID = EntityDataManager.<Integer>createKey(EntityTornadoBlock.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> BLOCK_META = EntityDataManager.<Integer>createKey(EntityTornadoBlock.class, DataSerializers.VARINT);

    private double orbitRadius = 2.0D;
    private double orbitAngle;
    private double orbitRise = 0.025D;
    private int age;

    public EntityTornadoBlock(World world) {
        super(world);
        this.setSize(0.98F, 0.98F);
        this.preventEntitySpawning = false;
    }

    public EntityTornadoBlock(World world, double x, double y, double z, IBlockState state) {
        this(world);
        this.setPosition(x, y, z);
        setCarriedState(state);
    }

    @Override
    protected void entityInit() {
        this.dataManager.register(BLOCK_ID, Block.getIdFromBlock(net.minecraft.init.Blocks.STONE));
        this.dataManager.register(BLOCK_META, 0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.isDead) return;
        this.age++;
        this.motionX = 0.0D;
        this.motionY = 0.0D;
        this.motionZ = 0.0D;
        this.prevRotationYaw = this.rotationYaw = 0.0F;
        this.prevRotationPitch = this.rotationPitch = 0.0F;
    }

    public IBlockState getCarriedState() {
        Block block = Block.getBlockById(this.dataManager.get(BLOCK_ID));
        if (block == null) block = net.minecraft.init.Blocks.STONE;
        return block.getStateFromMeta(this.dataManager.get(BLOCK_META));
    }

    public void setCarriedState(IBlockState state) {
        if (state == null) state = net.minecraft.init.Blocks.STONE.getDefaultState();
        this.dataManager.set(BLOCK_ID, Block.getIdFromBlock(state.getBlock()));
        this.dataManager.set(BLOCK_META, state.getBlock().getMetaFromState(state));
    }

    public double getOrbitRadius() { return orbitRadius; }
    public double getOrbitAngle() { return orbitAngle; }
    public double getOrbitRise() { return orbitRise; }

    public void setOrbit(double radius, double angle, double rise) {
        this.orbitRadius = radius;
        this.orbitAngle = angle;
        this.orbitRise = rise;
    }

    @Override
    public boolean canBeCollidedWith() { return false; }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) { return false; }

    @Override
    public boolean canBePushed() { return false; }

    @Override
    protected void readEntityFromNBT(NBTTagCompound tag) {
        if (tag.hasKey("BlockId")) {
            int id = tag.getInteger("BlockId");
            Block block = Block.getBlockById(id);
            if (block != null) {
                this.dataManager.set(BLOCK_ID, id);
                this.dataManager.set(BLOCK_META, tag.getInteger("BlockMeta"));
            }
        }
        this.orbitRadius = tag.getDouble("OrbitRadius");
        this.orbitAngle = tag.getDouble("OrbitAngle");
        this.orbitRise = tag.getDouble("OrbitRise");
        this.age = tag.getInteger("Age");
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound tag) {
        IBlockState state = getCarriedState();
        tag.setInteger("BlockId", Block.getIdFromBlock(state.getBlock()));
        tag.setInteger("BlockMeta", state.getBlock().getMetaFromState(state));
        tag.setDouble("OrbitRadius", orbitRadius);
        tag.setDouble("OrbitAngle", orbitAngle);
        tag.setDouble("OrbitRise", orbitRise);
        tag.setInteger("Age", age);
    }
}
